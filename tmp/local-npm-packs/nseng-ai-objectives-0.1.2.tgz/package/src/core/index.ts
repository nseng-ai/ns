export { createRealObjectiveContext, type ObjectiveCliContext } from "./context.ts";
export {
	FakeObjectiveStorageGateway,
	type FakeObjectiveRecordOptions,
	type FakeObjectiveStorageGatewayOptions,
} from "./fake-storage.ts";
export { RealObjectiveStorageGateway } from "./real-storage.ts";
export {
	objectiveRecordEdgeSchema,
	objectiveRecordFrontmatterParseSchema,
	objectiveRecordFrontmatterSchema,
	splitObjectiveRecordDocument,
	type ObjectiveRecordDocument,
	type ObjectiveRecordEdge,
	type ObjectiveRecordFrontmatter,
	type ObjectiveRecordFrontmatterParse,
} from "./record-frontmatter.ts";
export {
	ACTIVE_OBJECTIVE_ROOT,
	ObjectiveStorage,
	activeRecordRelativePath,
	activeRootRelativePath,
	emptyObjectiveFiles,
	isValidObjectiveSlug,
	objectiveSlugFromActivePath,
	renderFilePresence,
	type ObjectiveCheckoutInventory,
	type ObjectiveCheckoutRecord,
	type ObjectiveFiles,
	type ObjectiveMarkdownReadResult,
	type ObjectiveRecordDocumentReadResult,
	type ObjectiveRecordStatus,
	type ObjectiveStorageGateway,
	type ObjectiveStorageResult,
	type ObjectiveUpdateFile,
} from "./storage.ts";
