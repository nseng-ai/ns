import { dirname } from "node:path";

import {
	activeRecordRelativePath,
	type ObjectiveDirectoryEntry,
	type ObjectiveMarkdownReadResult,
	type ObjectivePathKind,
	type ObjectiveStorageError,
	type ObjectiveStorageGateway,
	type ObjectiveStorageResult,
} from "./storage.ts";

export interface FakeObjectiveRecordOptions {
	slug: string;
	objectiveMd?: string | null;
	roadmapMd?: string | null;
	orientationMd?: string | null;
	updates?: Readonly<Record<string, string>>;
	isClosed?: boolean;
}

export interface FakeObjectiveStorageGatewayOptions {
	files?: Readonly<Record<string, string>>;
	directories?: readonly string[];
	records?: readonly FakeObjectiveRecordOptions[];
	failures?: Readonly<Record<string, ObjectiveStorageError>>;
	unreadableFiles?: Readonly<Record<string, string>>;
}

export class FakeObjectiveStorageGateway implements ObjectiveStorageGateway {
	private readonly files = new Map<string, string>();
	private readonly directories = new Set<string>();
	private readonly failures: ReadonlyMap<string, ObjectiveStorageError>;
	private readonly unreadableFiles: ReadonlyMap<string, string>;

	constructor(options: FakeObjectiveStorageGatewayOptions = {}) {
		this.failures = new Map(
			Object.entries(options.failures ?? {}).map(([path, error]) => [
				normalizeRelativePath(path),
				{ ...error },
			]),
		);
		this.unreadableFiles = new Map(
			Object.entries(options.unreadableFiles ?? {}).map(([path, message]) => [
				normalizeRelativePath(path),
				message,
			]),
		);
		this.addDirectory(".");
		for (const directory of options.directories ?? []) {
			this.addDirectory(directory);
		}
		for (const record of options.records ?? []) {
			this.addObjectiveRecord(record);
		}
		for (const [path, content] of Object.entries(options.files ?? {})) {
			this.addFile(path, content);
		}
	}

	async pathKind(relativePath: string): Promise<ObjectiveStorageResult<ObjectivePathKind>> {
		const path = normalizeRelativePath(relativePath);
		const failure = this.failures.get(path);
		if (failure !== undefined) return { ok: false, error: { ...failure } };
		if (this.files.has(path)) return { ok: true, value: "file" };
		if (this.directories.has(path)) return { ok: true, value: "directory" };
		return { ok: true, value: "missing" };
	}

	async listDirectory(
		relativePath: string,
	): Promise<ObjectiveStorageResult<readonly ObjectiveDirectoryEntry[]>> {
		const path = normalizeRelativePath(relativePath);
		const failure = this.failures.get(path);
		if (failure !== undefined) return { ok: false, error: { ...failure } };
		if (!this.directories.has(path)) return { ok: true, value: [] };

		const entries = new Map<string, ObjectivePathKind>();
		for (const directory of this.directories) {
			if (directory === path) continue;
			const child = directChildName(path, directory);
			if (child !== null) entries.set(child, "directory");
		}
		for (const file of this.files.keys()) {
			const child = directChildName(path, file);
			if (child !== null && !entries.has(child)) entries.set(child, "file");
		}
		return {
			ok: true,
			value: [...entries.entries()]
				.map(([name, kind]) => ({ name, kind }))
				.sort((left, right) => left.name.localeCompare(right.name)),
		};
	}

	async readTextFile(relativePath: string): Promise<ObjectiveMarkdownReadResult> {
		const path = normalizeRelativePath(relativePath);
		const unreadable = this.unreadableFiles.get(path);
		if (unreadable !== undefined) return { type: "unreadable", message: unreadable };
		const content = this.files.get(path);
		if (content === undefined) return { type: "missing" };
		return { type: "ok", content };
	}

	addObjectiveRecord(record: FakeObjectiveRecordOptions): void {
		const root = activeRecordRelativePath(record.slug);
		this.addDirectory(root);
		if (record.objectiveMd !== null)
			this.addFile(`${root}/objective.md`, record.objectiveMd ?? `# ${record.slug}\n`);
		if (record.roadmapMd !== null)
			this.addFile(`${root}/roadmap.md`, record.roadmapMd ?? "# Roadmap\n");
		if (record.orientationMd !== undefined && record.orientationMd !== null) {
			this.addFile(`${root}/orientation.md`, record.orientationMd);
		}
		this.addDirectory(`${root}/updates`);
		for (const [name, content] of Object.entries(record.updates ?? {})) {
			this.addFile(`${root}/updates/${name}`, content);
		}
		if (record.isClosed === true) this.addFile(`${root}/closed.md`, "closed\n");
	}

	addDirectory(path: string): void {
		const normalized = normalizeRelativePath(path);
		if (normalized === "") return;
		const parent = normalizeRelativePath(dirname(normalized));
		if (parent !== "." && parent !== normalized) this.addDirectory(parent);
		this.directories.add(normalized);
	}

	addFile(path: string, content: string): void {
		const normalized = normalizeRelativePath(path);
		this.addDirectory(dirname(normalized));
		this.files.set(normalized, content);
	}
}

function normalizeRelativePath(path: string): string {
	return path.replaceAll("\\", "/").replace(/\/+$|^\.\//g, "") || ".";
}

function directChildName(parent: string, childPath: string): string | null {
	const normalizedParent = normalizeRelativePath(parent);
	const normalizedChild = normalizeRelativePath(childPath);
	const prefix = normalizedParent === "." ? "" : `${normalizedParent}/`;
	if (!normalizedChild.startsWith(prefix)) return null;
	const rest = normalizedChild.slice(prefix.length);
	if (rest.length === 0 || rest.includes("/")) return null;
	return rest;
}
