// House-style human renderer for `objective list`, built on the @nseng-ai/foundation/cli-theme display
// primitives (palette / glyphs / width helpers). This is the buffered "north-star" surface from the
// CLI UX design harness, ported onto the real Objective list result.
//
// It is a pure function over an injected `Caps` and `nowMs`, so every rung of the capability ladder
// (truecolor / 256 / 16 / mono) and the relative-time output are deterministic under test. The
// `--format json` machine path keeps the raw ISO stamp; only this human surface relativizes it.

import type { Caps } from "@nseng-ai/clinkr";
import {
	bold,
	dim,
	ellipsisFor,
	glyph,
	paint,
	padCell,
	padPlain,
	truncatePlain,
} from "@nseng-ai/foundation/cli-theme";

import {
	edgeCountCell,
	emptyMessage,
	formatStatusPlain,
	objectiveStatusPresentation,
	renderSlugs,
	updatedBranchCountCell,
	type ObjectiveListResult,
} from "./list-objectives.ts";

/** caps-aware truncation: ascii mode degrades the ellipsis to "..." too. */
function clip(caps: Caps, text: string, width: number): string {
	return truncatePlain(text, width, ellipsisFor(caps));
}

// Relative time for the human surface ("2 hours ago" beats a raw ISO stamp). `nowMs` is injected so
// output stays stable under test; the json path keeps the ISO.
function ago(count: number, word: string): string {
	return `${count} ${word}${count === 1 ? "" : "s"} ago`;
}

export function relativeTime(iso: string, nowMs: number): string {
	const then = Date.parse(iso);
	if (Number.isNaN(then)) return iso;
	const seconds = Math.max(0, Math.round((nowMs - then) / 1000));
	if (seconds < 45) return "just now";
	const minutes = Math.round(seconds / 60);
	if (minutes < 60) return ago(minutes, "minute");
	const hours = Math.round(minutes / 60);
	if (hours < 24) return ago(hours, "hour");
	const days = Math.round(hours / 24);
	if (days < 7) return ago(days, "day");
	if (days < 30) return ago(Math.round(days / 7), "week");
	if (days < 365) return ago(Math.round(days / 30), "month");
	return ago(Math.round(days / 365), "year");
}

function subtitle(result: ObjectiveListResult): string {
	const count = result.records.length;
	const noun = count === 1 ? "record" : "records";
	return dim(`${count} ${noun}  ·  filter ${result.statusFilter}  ·  root ${result.rootPath}`);
}

/**
 * Render the Objective list as the house-style human surface.
 *
 * Note on the table primitive: this list carries a separate fixed-width outstanding-changes gutter,
 * so it composes from the lower-level cell primitives (paint / glyph / padCell) rather than the flat
 * `renderTable` — which lays out exactly one line per row. That's a deliberate fit, not a gap.
 */
export function renderObjectiveListPretty(
	result: ObjectiveListResult,
	caps: Caps,
	nowMs: number,
): string {
	if (result.namesOnly) return renderSlugs(result.records);

	const lines: string[] = [bold("Objective records in this checkout"), subtitle(result)];
	if (result.records.length === 0) {
		lines.push("", emptyMessage(result.statusFilter));
		return lines.join("\n");
	}

	const maxSlug = Math.max(...result.records.map((r) => r.slug.length), "OBJECTIVE".length);
	const statusW = "X blocked".length; // widest plain status cell ("{glyph} blocked")
	const flagW = "x".length; // the outstanding-changes flag gets its own spaced column
	const branchesW = "BRANCHES".length; // Local non-trunk branch count; `show` lists names.
	const edgesW = "EDGES".length; // Objective Edge count, right of BRANCHES, blank when zero
	const slugW = Math.max(
		12,
		Math.min(maxSlug, caps.columns - statusW - flagW - branchesW - edgesW - 23),
	);
	const dateW = "LATEST UPDATE".length;

	lines.push("");
	// "LATEST UPDATE" sits above the dates; the flag gutter header stays blank.
	lines.push(
		dim(
			`${padPlain("OBJECTIVE", slugW)}  ${padPlain("STATUS", statusW)}  ${" ".repeat(flagW)}  ${padPlain("LATEST UPDATE", dateW)}  ${padPlain("BRANCHES", branchesW)}  EDGES`,
		),
	);

	for (const record of result.records) {
		const slugCell = padPlain(clip(caps, record.slug, slugW), slugW);

		const status = objectiveStatusPresentation(record);
		const statusGlyph = glyph(caps, status.glyphName);
		const statusColored = `${paint(caps, status.intent, statusGlyph)} ${status.word}`;
		const statusPlain = formatStatusPlain(caps, status);
		const statusCell = padCell(statusColored, statusPlain, statusW);

		const stamp =
			record.latestUpdateIso === null ? "—" : relativeTime(record.latestUpdateIso, nowMs);
		// A bare `x` warn marker in its own fixed-width column, explained once by the footer legend.
		const flagCell = record.hasOutstandingChanges ? paint(caps, "warn", "x") : " ".repeat(flagW);
		const dateCell = dim(padPlain(clip(caps, stamp, dateW), dateW));
		const branchesCell = padPlain(updatedBranchCountCell(record), branchesW);
		const edgesCell = edgeCountCell(record);

		lines.push(
			`${slugCell}  ${statusCell}  ${flagCell}  ${dateCell}  ${branchesCell}  ${edgesCell}`.trimEnd(),
		);
	}

	const legends: string[] = [];
	if (result.records.some((record) => record.hasOutstandingChanges)) {
		legends.push(dim("x = uncommitted changes not yet recorded in an update"));
	}
	if (legends.length > 0) lines.push("", ...legends);

	return lines.join("\n");
}
