import { defineExtension } from "@nseng-ai/ns/kernel/sdk";

import { objectiveNsCommand } from "../command.ts";
import {
	readObjectiveRequestSchema,
	readObjectiveResultSchema,
	renderReadObjective,
	runReadObjective,
} from "../../core/operations/read-objective.ts";

export const objectiveExecReadObjectiveNsCommand = objectiveNsCommand({
	name: "exec-read-objective",
	summary: "Read one Objective record by explicit slug as filesystem facts or raw Markdown.",
	description: "Read one Objective record by explicit slug as filesystem facts or raw Markdown.",
	schema: readObjectiveRequestSchema,
	resultSchema: readObjectiveResultSchema,
	positionals: { slug: { position: 0 } },
	handler: runReadObjective,
	renderHuman: renderReadObjective,
	renderMarkdown: renderReadObjective,
});

export default defineExtension({
	commands: [objectiveExecReadObjectiveNsCommand],
});
