import { defineExtension } from "@nseng-ai/ns/kernel/sdk";

import { objectiveNsCommand } from "../command.ts";
import {
	renderRunnerSubagentUsageMarkdown,
	runnerSubagentUsageRequestSchema,
	runnerSubagentUsageResultSchema,
	runRunnerSubagentUsage,
} from "../../core/operations/runner-subagent-usage.ts";

export const objectiveExecRunnerSubagentUsageNsCommand = objectiveNsCommand({
	name: "exec-runner-subagent-usage",
	summary: "Summarize Pi runner subagent JSONL usage telemetry for Objective stack digests.",
	description: "Summarize Pi runner subagent JSONL usage telemetry for Objective stack digests.",
	schema: runnerSubagentUsageRequestSchema,
	resultSchema: runnerSubagentUsageResultSchema,
	positionals: { sessionFiles: { position: 0 } },
	handler: runRunnerSubagentUsage,
	renderHuman: renderRunnerSubagentUsageMarkdown,
	renderMarkdown: renderRunnerSubagentUsageMarkdown,
});

export default defineExtension({
	commands: [objectiveExecRunnerSubagentUsageNsCommand],
});
